import 'dart:convert';
import 'dart:developer';

import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:loginpage/core/secure_storage.dart';
import 'package:loginpage/features/home/data/model/checkin_model.dart';

class CheckinRepository {
  static const String url =
      "https://disa-uat.m.frappe.cloud/api/method/disa_backend.api.v1.employee.employee_checkin";

  Future<void> submit(CheckinRequest request) async {
    final token = await SecureStorageHelper.getToken();

    final apiRequest = http.MultipartRequest("POST", Uri.parse(url));

    apiRequest.headers.addAll({"Authorization": "Basic $token"});

    final selfieBytes = await request.selfieImage.readAsBytes();
    final selfieBase64 = base64Encode(selfieBytes);

    log("Selfie bytes: ${selfieBytes.length}");
    log("Selfie base64 length: ${selfieBase64.length}");
    log("Selfie base64 first 100 chars: ${selfieBase64.substring(0, 100)}");

    final odometerBytes = await request.odometerImage.readAsBytes();
    final odometerBase64 = base64Encode(odometerBytes);

    apiRequest.fields["log_type"] = request.logType;
    apiRequest.fields["odometer_value"] = request.odometerValue;
    apiRequest.fields["latitude"] = request.latitude.toString();
    apiRequest.fields["longitude"] = request.longitude.toString();
    apiRequest.fields["time"] = DateTime.now().toIso8601String();
    apiRequest.fields["selfie"] = selfieBase64;
    apiRequest.fields["odometer_image"] = odometerBase64;

    log("========== CHECK-IN REQUEST ==========");
    log("URL : $url");
    log("Token : $token");
    log("Log Type : ${request.logType}");
    log("Odometer Value : ${request.odometerValue}");
    log("Latitude : ${request.latitude}");
    log("Longitude : ${request.longitude}");
    log("Time : ${DateTime.now().toIso8601String()}");
    log("Selfie Base64 Length : ${selfieBase64.length}");
    log("Odometer Base64 Length : ${odometerBase64.length}");
    log("Request Fields : ${apiRequest.fields.keys}");
    log("======================================");

    final response = await apiRequest.send();
    final responseBody = await response.stream.bytesToString();

    log("========== CHECK-IN RESPONSE ==========");
    log("Status Code : ${response.statusCode}");
    log("Response Body : $responseBody");
    log("=======================================");

    if (response.statusCode != 200) {
      throw Exception(
        "Check-In Failed\nStatus: ${response.statusCode}\n$responseBody",
      );
    }

    final data = jsonDecode(responseBody);

    if (data["message"]["success"] == false) {
      throw Exception(data["message"]["message"]);
    }
  }

  Future<Position> getLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      throw Exception("Location Service Disabled");
    }

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.deniedForever) {
      throw Exception("Location Permission Denied Forever");
    }

    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }
}
